"""
Migration script to add document_ids column to chat_sessions table
"""
import sqlite3
import json

# Connect to the database
conn = sqlite3.connect('rag_app.db')
cursor = conn.cursor()

try:
    # Check if column already exists
    cursor.execute("PRAGMA table_info(chat_sessions)")
    columns = [col[1] for col in cursor.fetchall()]

    if 'document_ids' not in columns:
        print("Adding document_ids column to chat_sessions table...")

        # Add document_ids column
        cursor.execute("ALTER TABLE chat_sessions ADD COLUMN document_ids TEXT")

        # Make document_id nullable by recreating the table (SQLite limitation)
        # For now, we'll just populate document_ids with existing document_id
        cursor.execute("SELECT id, document_id FROM chat_sessions")
        sessions = cursor.fetchall()

        for session_id, document_id in sessions:
            if document_id:
                doc_ids_json = json.dumps([document_id])
                cursor.execute(
                    "UPDATE chat_sessions SET document_ids = ? WHERE id = ?",
                    (doc_ids_json, session_id)
                )

        conn.commit()
        print(f"✓ Migration completed successfully! Updated {len(sessions)} sessions.")
    else:
        print("✓ Column document_ids already exists. No migration needed.")

except Exception as e:
    print(f"✗ Migration failed: {e}")
    conn.rollback()
finally:
    conn.close()
