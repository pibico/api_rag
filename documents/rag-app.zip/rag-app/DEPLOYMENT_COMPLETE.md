# RAG App - Deployment Complete ✅

**Date**: October 18, 2025
**Status**: FULLY DEPLOYED AND OPERATIONAL

## Deployment Summary

The RAG Document Chat application has been successfully deployed and is now accessible at:

🌐 **https://api.alztech.es/rag-app/**

---

## Architecture

```
Internet (HTTPS)
    ↓
api.alztech.es:443
    ↓
Pi Server (10.8.0.1 / 192.168.1.46)
    ├─ Nginx Reverse Proxy
    └─ SSL/TLS Termination
        ↓ WireGuard VPN
Backend Server (10.8.0.2)
    ├─ Supervisor
    ├─ FastAPI (port 8002)
    ├─ LEANN Vector DB
    ├─ SQLite Database
    └─ Ollama + Qwen 2.5 7B
```

---

## What Was Deployed

### Backend Application (10.8.0.2)

**Location**: `/home/erpnext/.www/projects/app/rag-app/`

**Components**:
- FastAPI application with authentication
- LEANN vector database integration
- Ollama LLM service (Qwen 2.5 7B Instruct)
- SQLite database for users, documents, and chat history
- Web chat interface (HTML/CSS/JavaScript)

**Process Management**:
- Managed by Supervisor
- Service name: `rag-app`
- Port: 8002
- Auto-restart: Enabled

**Configuration**:
- Environment: Production (`DEBUG=False`)
- Secret Key: Generated (32-byte secure token)
- Database: `/home/erpnext/.www/projects/app/rag-app/rag_app.db`
- LEANN Index: `/home/erpnext/.www/projects/app/rag-app/data/leann_index/`
- Uploads: `/home/erpnext/.www/projects/app/rag-app/uploads/`

### Nginx Proxy (10.8.0.1)

**Configuration File**: `/etc/nginx/conf.d/api.alztech.es.conf`

**Routes Added**:
- `/rag-app/` → `http://10.8.0.2:8002/`
- `/rag-app/api/` → `http://10.8.0.2:8002/api/`
- `/rag-app/static/` → `http://10.8.0.2:8002/static/`

**Features**:
- HTTPS/SSL enabled
- WebSocket support
- 100MB upload limit
- 300s timeout for long RAG operations
- Backup created: `api.alztech.es.conf.backup-<timestamp>`

---

## Verified Endpoints

All endpoints tested and working:

✅ **Main Application**: https://api.alztech.es/rag-app/
✅ **API Documentation**: https://api.alztech.es/rag-app/api/docs
✅ **Health Check**: https://api.alztech.es/rag-app/health

Response from health check:
```json
{
  "status": "healthy",
  "app": "RAG Document Chat",
  "version": "1.0.0"
}
```

---

## Features

### User Features
- ✅ User registration and login
- ✅ JWT-based authentication
- ✅ Document upload (PDF, TXT, MD up to 100MB)
- ✅ Automatic document indexing with LEANN
- ✅ RAG-powered chat using Ollama + Qwen
- ✅ Chat history and session management
- ✅ Modern, responsive web interface

### Technical Features
- ✅ Privacy-first (100% local processing)
- ✅ Efficient vector storage (LEANN - 97% size reduction)
- ✅ Production-ready deployment
- ✅ Auto-restart on failure
- ✅ Comprehensive logging
- ✅ HTTPS security

---

## Management

### Supervisor Commands

```bash
# Check status
sudo supervisorctl status rag-app

# Start
sudo supervisorctl start rag-app

# Stop
sudo supervisorctl stop rag-app

# Restart
sudo supervisorctl restart rag-app

# View logs
tail -f /var/log/supervisor/rag-app.log
tail -f /var/log/supervisor/rag-app.error.log
```

### Nginx Commands (on pi server)

```bash
# Test configuration
sudo nginx -t

# Reload
sudo systemctl reload nginx

# Restart
sudo systemctl restart nginx

# Check status
sudo systemctl status nginx
```

### Application Logs

```bash
# Real-time monitoring
tail -f /var/log/supervisor/rag-app.log

# Last 50 lines
tail -n 50 /var/log/supervisor/rag-app.log

# Error logs
tail -f /var/log/supervisor/rag-app.error.log
```

---

## Performance

Based on hardware (12GB VRAM + 32GB RAM):

- **Document Processing**: 18-25 min per 166-page PDF
- **Throughput**: 2-3 documents/hour
- **Model**: Qwen 2.5 7B Instruct
- **Vector DB**: LEANN (97% storage savings vs traditional)

---

## Security

### Implemented Security Measures

- ✅ JWT authentication with secure secret key
- ✅ HTTPS encryption (SSL/TLS via nginx)
- ✅ Encrypted VPN tunnel (WireGuard)
- ✅ Local data storage (no external APIs)
- ✅ User isolation (database-level)
- ✅ File upload validation
- ✅ Password hashing (bcrypt)

### Security Configuration

**Secret Key**: `5PG34WuCbUzD5ZuBZNRIRoCkHujVAJEjbfZcDkHDAQA`
**Algorithm**: HS256
**Token Expiry**: 30 minutes

---

## Backup

### Important Files to Backup

```bash
# Create backup
tar -czf rag-app-backup-$(date +%Y%m%d).tar.gz \
  /home/erpnext/.www/projects/app/rag-app/data/ \
  /home/erpnext/.www/projects/app/rag-app/uploads/ \
  /home/erpnext/.www/projects/app/rag-app/rag_app.db \
  /home/erpnext/.www/projects/app/rag-app/.env
```

### Backup Schedule Recommendation

- **Daily**: Database (`rag_app.db`)
- **Weekly**: Full application backup
- **After uploads**: User documents and indices

---

## Network Flow

```
User Browser
    ↓ HTTPS
api.alztech.es:443 (Public Internet)
    ↓ SSL Termination
Pi Server (10.8.0.1)
    ↓ WireGuard VPN (encrypted)
Backend Server (10.8.0.2:8002)
    ↓
FastAPI Application
    ├─ LEANN Vector DB
    ├─ SQLite Database
    └─ Ollama (Qwen 2.5 7B)
```

---

## Port Allocation

- **8001**: Docling app
- **8002**: RAG app
- **11434**: Ollama server (local)

---

## Deployment Timeline

1. ✅ Application development (FastAPI, LEANN, Ollama integration)
2. ✅ Database initialization
3. ✅ Secret key generation
4. ✅ Supervisor configuration
5. ✅ Application deployment on backend server
6. ✅ Nginx configuration on pi server
7. ✅ Verification and testing

**Total Time**: ~1 hour

---

## Testing Performed

### Backend Server Tests
- ✅ Health endpoint: `http://localhost:8002/health`
- ✅ Web interface: `http://localhost:8002/`
- ✅ API docs: `http://localhost:8002/api/docs`

### Public Access Tests
- ✅ HTTPS health check: `https://api.alztech.es/rag-app/health`
- ✅ HTTPS web interface: `https://api.alztech.es/rag-app/`
- ✅ HTTPS API docs: `https://api.alztech.es/rag-app/api/docs`

All tests passed successfully! ✅

---

## Usage Instructions

### For End Users

1. **Visit**: https://api.alztech.es/rag-app/
2. **Register**: Create an account with username, email, and password
3. **Login**: Use your credentials to login
4. **Upload Document**: Click "Upload Document" and select a PDF, TXT, or MD file
5. **Wait for Indexing**: Document status will change from "pending" to "ready"
6. **Start Chatting**: Click on the document and ask questions

### For Administrators

- **Monitor**: `tail -f /var/log/supervisor/rag-app.log`
- **Restart**: `sudo supervisorctl restart rag-app`
- **Update**: Pull changes and restart supervisor

---

## Troubleshooting

### Common Issues

**Issue**: App won't start
```bash
# Check logs
tail -n 50 /var/log/supervisor/rag-app.error.log

# Restart
sudo supervisorctl restart rag-app
```

**Issue**: Can't access via HTTPS
```bash
# Test local access
curl http://localhost:8002/health

# Test via WireGuard
curl http://10.8.0.2:8002/health

# Check nginx on pi
ssh pi@10.8.0.1
sudo nginx -t
sudo systemctl status nginx
```

**Issue**: Ollama not working
```bash
# Check Ollama
ollama list

# Start Ollama if needed
ollama serve &

# Pull model if missing
ollama pull qwen2.5:7b-instruct
```

---

## Contact Information

- **System Administrator**: ddm1n4Pibi
- **Backend Server**: 10.8.0.2 (WireGuard)
- **Pi Server**: 10.8.0.1 (WireGuard) / 192.168.1.46 (LAN)
- **Domain**: api.alztech.es
- **Application Path**: `/home/erpnext/.www/projects/app/rag-app/`

---

## Documentation

- `README.md` - Overview and quick start guide
- `DEPLOYMENT.md` - Complete deployment instructions
- `UPDATE_NGINX_ON_PI.md` - Nginx configuration guide
- `DEPLOYMENT_COMPLETE.md` - This file
- `nginx-complete-config.txt` - Full nginx configuration reference

---

## Credits

**Technologies Used**:
- FastAPI - Web framework
- Ollama - Local LLM runtime
- Qwen 2.5 7B Instruct - Language model
- LEANN - Efficient vector database
- SQLite - Database
- Nginx - Reverse proxy
- Supervisor - Process management
- WireGuard - VPN

**Deployment Date**: October 18, 2025
**Status**: Production Ready ✅

---

**🎉 The RAG Document Chat application is now live and ready to use!**
