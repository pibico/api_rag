// RAG Document Chat - Frontend JavaScript

const API_BASE = 'api';
let authToken = localStorage.getItem('authToken');
let selectedDocuments = [];  // Changed to array for multi-select
let currentSession = null;
let documents = [];
let sessions = [];
let currentUser = null;
let isAdmin = false;

// Toast notification system
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
        success: '✓',
        error: '✕',
        info: 'ℹ'
    };

    toast.innerHTML = `
        <span class="toast-icon">${icons[type] || icons.info}</span>
        <span class="toast-message">${message}</span>
        <span class="toast-close">×</span>
    `;

    container.appendChild(toast);

    // Close button
    toast.querySelector('.toast-close').addEventListener('click', () => {
        closeToast(toast);
    });

    // Auto close after 4 seconds
    setTimeout(() => {
        closeToast(toast);
    }, 4000);
}

function closeToast(toast) {
    toast.classList.add('fade-out');
    setTimeout(() => {
        toast.remove();
    }, 300);
}

// Confirmation modal system
let confirmResolve = null;

function showConfirm(message, title = 'Confirm Action') {
    return new Promise((resolve) => {
        confirmResolve = resolve;
        const modal = document.getElementById('confirm-modal');
        document.getElementById('confirm-title').textContent = title;
        document.getElementById('confirm-message').textContent = message;
        modal.style.display = 'block';
    });
}

function hideConfirmModal() {
    document.getElementById('confirm-modal').style.display = 'none';
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    if (authToken) {
        loadUserInfo().then(() => {
            showChatScreen();
            loadDocuments();
            loadSessions();
        });
    } else {
        showAuthScreen();
    }

    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Auth forms
    document.getElementById('login-form').addEventListener('submit', handleLogin);

    // Logout
    document.getElementById('logout-btn').addEventListener('click', handleLogout);

    // Upload
    document.getElementById('upload-btn').addEventListener('click', () => {
        document.getElementById('upload-modal').style.display = 'block';
    });

    // Upload modal
    document.querySelector('.close').addEventListener('click', () => {
        document.getElementById('upload-modal').style.display = 'none';
    });

    document.getElementById('upload-form').addEventListener('submit', handleUpload);

    // Admin panel
    document.getElementById('manage-users-btn').addEventListener('click', () => {
        document.getElementById('admin-modal').style.display = 'block';
        loadUsers();
    });

    // Admin modal
    document.querySelector('.close-admin').addEventListener('click', () => {
        document.getElementById('admin-modal').style.display = 'none';
    });

    // Admin tabs
    document.getElementById('create-user-tab').addEventListener('click', () => {
        switchAdminTab('create');
    });
    document.getElementById('list-users-tab').addEventListener('click', () => {
        switchAdminTab('list');
        loadUsers();
    });

    document.getElementById('admin-create-user-form').addEventListener('submit', handleAdminCreateUser);

    // Confirmation modal buttons
    document.getElementById('confirm-yes').addEventListener('click', () => {
        if (confirmResolve) {
            confirmResolve(true);
            confirmResolve = null;
        }
        hideConfirmModal();
    });

    document.getElementById('confirm-no').addEventListener('click', () => {
        if (confirmResolve) {
            confirmResolve(false);
            confirmResolve = null;
        }
        hideConfirmModal();
    });

    // Chat
    document.getElementById('send-btn').addEventListener('click', sendMessage);
    document.getElementById('chat-input').addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
}

// Handle login
async function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    const errorDiv = document.getElementById('login-error');

    try {
        const formData = new FormData();
        formData.append('username', username);
        formData.append('password', password);

        const response = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const data = await response.json();
            authToken = data.access_token;
            localStorage.setItem('authToken', authToken);
            await loadUserInfo();
            showChatScreen();
            loadDocuments();
            loadSessions();
        } else {
            const error = await response.json();
            errorDiv.textContent = error.detail || 'Login failed';
        }
    } catch (error) {
        errorDiv.textContent = 'Error connecting to server';
    }
}

// Handle logout
function handleLogout() {
    authToken = null;
    localStorage.removeItem('authToken');
    currentDocument = null;
    currentSession = null;
    showAuthScreen();
}

// Show auth screen
function showAuthScreen() {
    document.getElementById('auth-screen').style.display = 'flex';
    document.getElementById('chat-screen').style.display = 'none';
}

// Show chat screen
function showChatScreen() {
    document.getElementById('auth-screen').style.display = 'none';
    document.getElementById('chat-screen').style.display = 'flex';
}

// Load documents
async function loadDocuments() {
    try {
        const response = await fetch(`${API_BASE}/documents/`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            documents = await response.json();
            renderDocuments();
        }
    } catch (error) {
        console.error('Error loading documents:', error);
    }
}

// Render documents
function renderDocuments() {
    const list = document.getElementById('documents-list');
    list.innerHTML = '';

    // Count ready documents
    const readyDocs = documents.filter(d => d.status === 'ready');

    // Add instruction or "Start Chat" button
    if (selectedDocuments.length > 0) {
        const startChatSection = document.createElement('div');
        startChatSection.style.marginBottom = '8px';
        startChatSection.style.padding = '6px';
        startChatSection.style.background = 'rgba(70, 130, 180, 0.1)';
        startChatSection.style.borderRadius = '4px';
        startChatSection.style.border = '1px solid var(--primary)';

        const selectionText = document.createElement('div');
        selectionText.style.fontSize = '11px';
        selectionText.style.color = 'var(--primary)';
        selectionText.style.marginBottom = '4px';
        selectionText.style.fontWeight = '600';
        selectionText.textContent = `${selectedDocuments.length} document${selectedDocuments.length > 1 ? 's' : ''} selected`;
        startChatSection.appendChild(selectionText);

        const startChatBtn = document.createElement('button');
        startChatBtn.className = 'btn btn-primary';
        startChatBtn.textContent = '▶ Start New Chat';
        startChatBtn.style.width = '100%';
        startChatBtn.style.fontWeight = '600';
        startChatBtn.addEventListener('click', startMultiDocChat);
        startChatSection.appendChild(startChatBtn);

        list.appendChild(startChatSection);
    } else if (readyDocs.length > 0) {
        // Show "Chat with All" button when no documents selected
        const allDocsSection = document.createElement('div');
        allDocsSection.style.marginBottom = '8px';
        allDocsSection.style.padding = '6px';
        allDocsSection.style.background = 'rgba(46, 204, 113, 0.1)';
        allDocsSection.style.borderRadius = '4px';
        allDocsSection.style.border = '1px solid var(--success)';

        const instructionText = document.createElement('div');
        instructionText.style.fontSize = '11px';
        instructionText.style.color = '#27ae60';
        instructionText.style.marginBottom = '4px';
        instructionText.style.fontWeight = '600';
        instructionText.textContent = `${readyDocs.length} document${readyDocs.length > 1 ? 's' : ''} available`;
        allDocsSection.appendChild(instructionText);

        const chatAllBtn = document.createElement('button');
        chatAllBtn.className = 'btn';
        chatAllBtn.textContent = '▶ Chat with All Documents';
        chatAllBtn.style.width = '100%';
        chatAllBtn.style.fontWeight = '600';
        chatAllBtn.style.background = 'linear-gradient(135deg, #27ae60 0%, #2ecc71 100%)';
        chatAllBtn.style.color = 'white';
        chatAllBtn.style.boxShadow = '0 4px 12px rgba(46, 204, 113, 0.3)';
        chatAllBtn.addEventListener('click', chatWithAllDocuments);
        allDocsSection.appendChild(chatAllBtn);

        const orDivider = document.createElement('div');
        orDivider.style.fontSize = '10px';
        orDivider.style.color = '#7f8c8d';
        orDivider.style.textAlign = 'center';
        orDivider.style.margin = '4px 0';
        orDivider.textContent = '— or select specific documents —';
        allDocsSection.appendChild(orDivider);

        list.appendChild(allDocsSection);
    }

    documents.forEach(doc => {
        const item = document.createElement('div');
        const isSelected = selectedDocuments.some(d => d.id === doc.id);
        item.className = `document-item ${isSelected ? 'active' : ''}`;
        item.innerHTML = `
            <input type="checkbox" class="doc-checkbox" data-doc-id="${doc.id}" ${isSelected ? 'checked' : ''} ${doc.status !== 'ready' ? 'disabled' : ''} style="margin-right: 6px; cursor: pointer;">
            <div class="document-info" data-doc-id="${doc.id}" style="flex: 1;">
                <div class="document-title">${doc.title}</div>
                <div class="document-status status-${doc.status}">${doc.status}</div>
            </div>
            <button class="btn-delete-doc" data-doc-id="${doc.id}" data-doc-title="${doc.title}" title="Delete document">×</button>
        `;

        // Add checkbox event listener
        const checkbox = item.querySelector('.doc-checkbox');
        checkbox.addEventListener('change', (e) => {
            e.stopPropagation();
            if (e.target.checked) {
                if (!selectedDocuments.some(d => d.id === doc.id)) {
                    selectedDocuments.push(doc);
                }
            } else {
                selectedDocuments = selectedDocuments.filter(d => d.id !== doc.id);
            }
            renderDocuments();
        });

        // Add delete button event listener
        const deleteBtn = item.querySelector('.btn-delete-doc');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', (e) => {
                console.log('Delete button clicked for document:', doc.id);
                e.stopPropagation();
                e.preventDefault();
                confirmDeleteDocument(doc.id, doc.title);
            });
        }

        list.appendChild(item);
    });
}

// Chat with all documents
async function chatWithAllDocuments() {
    const readyDocs = documents.filter(d => d.status === 'ready');

    if (readyDocs.length === 0) {
        showToast('No ready documents available', 'info');
        return;
    }

    // Create session with all ready documents
    try {
        const docIds = readyDocs.map(d => d.id);
        const titles = readyDocs.map(d => d.title);

        const response = await fetch(`${API_BASE}/chat/sessions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                document_ids: docIds,
                title: `Chat with all documents (${docIds.length})`
            })
        });

        if (response.ok) {
            currentSession = await response.json();
            document.getElementById('chat-title').textContent = `All Documents (${docIds.length}): ${titles.join(', ')}`;
            document.getElementById('chat-input').disabled = false;
            document.getElementById('send-btn').disabled = false;
            document.getElementById('chat-messages').innerHTML = '';
            loadSessions();
            showToast(`Started chat with ${docIds.length} documents!`, 'success');
        } else {
            const error = await response.json();
            showToast(error.detail || 'Failed to create chat session', 'error');
        }
    } catch (error) {
        console.error('Error creating session:', error);
        showToast('Error creating chat session', 'error');
    }
}

// Start multi-document chat
async function startMultiDocChat() {
    if (selectedDocuments.length === 0) {
        showToast('Please select at least one document', 'info');
        return;
    }

    // Create new chat session with multiple documents
    try {
        const docIds = selectedDocuments.map(d => d.id);
        const titles = selectedDocuments.map(d => d.title);

        const response = await fetch(`${API_BASE}/chat/sessions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                document_ids: docIds,
                title: docIds.length === 1 ? `Chat about ${titles[0]}` : `Chat about ${docIds.length} documents`
            })
        });

        if (response.ok) {
            currentSession = await response.json();
            const headerText = docIds.length === 1 ? titles[0] : `${docIds.length} documents: ${titles.join(', ')}`;
            document.getElementById('chat-title').textContent = headerText;
            document.getElementById('chat-input').disabled = false;
            document.getElementById('send-btn').disabled = false;
            document.getElementById('chat-messages').innerHTML = '';
            loadSessions();
            showToast(`Started chat with ${docIds.length} document${docIds.length > 1 ? 's' : ''}!`, 'success');
        } else {
            const error = await response.json();
            showToast(error.detail || 'Failed to create chat session', 'error');
        }
    } catch (error) {
        console.error('Error creating session:', error);
        showToast('Error creating chat session', 'error');
    }
}

// Load sessions
async function loadSessions() {
    try {
        const response = await fetch(`${API_BASE}/chat/sessions`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            sessions = await response.json();
            renderSessions();
        }
    } catch (error) {
        console.error('Error loading sessions:', error);
    }
}

// Render sessions
function renderSessions() {
    const list = document.getElementById('sessions-list');
    list.innerHTML = '';

    sessions.slice(0, 10).forEach(session => {
        const item = document.createElement('div');
        item.className = `session-item ${currentSession?.id === session.id ? 'active' : ''}`;
        item.innerHTML = `
            <div class="session-info" data-session-id="${session.id}">
                <div class="session-title">${session.title}</div>
            </div>
            <button class="btn-delete-session" data-session-id="${session.id}" data-session-title="${session.title}" title="Delete session">×</button>
        `;

        // Add click handler for session info (not the delete button)
        const sessionInfo = item.querySelector('.session-info');
        sessionInfo.addEventListener('click', () => loadSession(session.id));

        // Add delete button event listener
        const deleteBtn = item.querySelector('.btn-delete-session');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', (e) => {
                console.log('Delete button clicked for session:', session.id);
                e.stopPropagation(); // Prevent selecting the session
                e.preventDefault(); // Prevent any default behavior
                confirmDeleteSession(session.id, session.title);
            });
        } else {
            console.error('Delete button not found for session:', session.id);
        }

        list.appendChild(item);
    });
}

// Load session
async function loadSession(sessionId) {
    try {
        const response = await fetch(`${API_BASE}/chat/sessions/${sessionId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            currentSession = await response.json();
            renderMessages(currentSession.messages);
            document.getElementById('chat-input').disabled = false;
            document.getElementById('send-btn').disabled = false;
        }
    } catch (error) {
        console.error('Error loading session:', error);
    }
}

// Render messages
function renderMessages(messages) {
    const container = document.getElementById('chat-messages');
    container.innerHTML = '';

    messages.forEach(msg => {
        addMessage(msg.role, msg.content);
    });

    container.scrollTop = container.scrollHeight;
}

// Handle upload
async function handleUpload(e) {
    e.preventDefault();
    const title = document.getElementById('doc-title').value;
    const file = document.getElementById('doc-file').files[0];
    const statusDiv = document.getElementById('upload-status');

    if (!file) {
        statusDiv.textContent = 'Please select a file';
        statusDiv.className = 'status-error';
        return;
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('file', file);

    try {
        statusDiv.textContent = 'Uploading...';
        statusDiv.className = '';

        const response = await fetch(`${API_BASE}/documents/upload`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${authToken}` },
            body: formData
        });

        if (response.ok) {
            const data = await response.json();
            statusDiv.textContent = 'Document uploaded successfully! Indexing in progress...';
            statusDiv.className = 'status-success';

            document.getElementById('upload-form').reset();
            setTimeout(() => {
                document.getElementById('upload-modal').style.display = 'none';
                statusDiv.textContent = '';
                loadDocuments();
            }, 2000);
        } else {
            const error = await response.json();
            statusDiv.textContent = error.detail || 'Upload failed';
            statusDiv.className = 'status-error';
        }
    } catch (error) {
        statusDiv.textContent = 'Error uploading document';
        statusDiv.className = 'status-error';
    }
}

// Send message
async function sendMessage() {
    const input = document.getElementById('chat-input');
    const query = input.value.trim();

    if (!query || !currentSession) return;

    // Capture query timestamp
    const queryTime = new Date();

    // Add user message with timestamp
    addMessage('user', query, { timestamp: queryTime });
    input.value = '';

    // Show typing indicator
    const typingIndicator = addTypingIndicator();

    try {
        const response = await fetch(`${API_BASE}/chat/query`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query,
                session_id: currentSession.id,
                top_k: 5
            })
        });

        // Remove typing indicator
        typingIndicator.remove();

        if (response.ok) {
            const data = await response.json();
            // Add assistant message with timing info
            addMessage('assistant', data.answer, {
                queryTimestamp: new Date(data.query_timestamp),
                responseTimestamp: new Date(data.response_timestamp),
                elapsedTime: data.elapsed_time
            });
        } else {
            addMessage('assistant', 'Sorry, I encountered an error processing your question.');
        }
    } catch (error) {
        typingIndicator.remove();
        addMessage('assistant', 'Sorry, I encountered an error processing your question.');
    }
}

// Add message to chat
function addMessage(role, content, meta = {}) {
    const container = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;

    let metaHtml = '';

    if (role === 'user' && meta.timestamp) {
        // For user messages, show timestamp
        metaHtml = `<div class="message-meta">Sent: ${formatTimestamp(meta.timestamp)}</div>`;
    } else if (role === 'assistant' && meta.elapsedTime !== undefined) {
        // For assistant messages, show query time, response time, and elapsed time
        const queryTimeStr = meta.queryTimestamp ? formatTimestamp(meta.queryTimestamp) : '';
        const responseTimeStr = meta.responseTimestamp ? formatTimestamp(meta.responseTimestamp) : '';
        const elapsedTimeStr = formatElapsedTime(meta.elapsedTime);

        metaHtml = `<div class="message-meta">Asked: ${queryTimeStr} | Answered: ${responseTimeStr} | Took: ${elapsedTimeStr}</div>`;
    }

    messageDiv.innerHTML = `
        <div class="message-content">
            ${formatMessage(content)}
        </div>
        ${metaHtml}
    `;
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
}

// Format timestamp
function formatTimestamp(date) {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}

// Format elapsed time
function formatElapsedTime(seconds) {
    if (seconds < 1) {
        return `${(seconds * 1000).toFixed(0)}ms`;
    } else if (seconds < 60) {
        return `${seconds.toFixed(2)}s`;
    } else {
        const mins = Math.floor(seconds / 60);
        const secs = (seconds % 60).toFixed(0);
        return `${mins}m ${secs}s`;
    }
}

// Add typing indicator
function addTypingIndicator() {
    const container = document.getElementById('chat-messages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message assistant';
    typingDiv.innerHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    container.appendChild(typingDiv);
    container.scrollTop = container.scrollHeight;
    return typingDiv;
}

// Format message (simple markdown-like formatting)
function formatMessage(text) {
    // Escape HTML
    text = text.replace(/</g, '&lt;').replace(/>/g, '&gt;');

    // Convert code blocks
    text = text.replace(/```([\s\S]*?)```/g, '<pre>$1</pre>');

    // Convert line breaks
    text = text.replace(/\n/g, '<br>');

    return text;
}

// Load user info
async function loadUserInfo() {
    try {
        const response = await fetch(`${API_BASE}/auth/me`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            currentUser = await response.json();
            isAdmin = currentUser.is_superuser || false;

            // Show/hide admin panel
            if (isAdmin) {
                document.getElementById('admin-section').style.display = 'block';
            } else {
                document.getElementById('admin-section').style.display = 'none';
            }
        }
    } catch (error) {
        console.error('Error loading user info:', error);
    }
}

// Switch admin tab
function switchAdminTab(tab) {
    const createTab = document.getElementById('create-user-tab');
    const listTab = document.getElementById('list-users-tab');
    const createPanel = document.getElementById('create-user-panel');
    const listPanel = document.getElementById('list-users-panel');

    if (tab === 'create') {
        createTab.classList.add('active');
        listTab.classList.remove('active');
        createPanel.classList.add('active');
        listPanel.classList.remove('active');
    } else {
        createTab.classList.remove('active');
        listTab.classList.add('active');
        createPanel.classList.remove('active');
        listPanel.classList.add('active');
    }
}

// Handle admin create user
async function handleAdminCreateUser(e) {
    e.preventDefault();
    const username = document.getElementById('admin-username').value;
    const email = document.getElementById('admin-email').value;
    const fullName = document.getElementById('admin-fullname').value;
    const password = document.getElementById('admin-password').value;
    const confirmPassword = document.getElementById('admin-confirm-password').value;
    const statusDiv = document.getElementById('admin-create-status');

    if (password !== confirmPassword) {
        statusDiv.textContent = 'Passwords do not match';
        statusDiv.className = 'status-error';
        return;
    }

    if (password.length < 6) {
        statusDiv.textContent = 'Password must be at least 6 characters';
        statusDiv.className = 'status-error';
        return;
    }

    try {
        statusDiv.textContent = 'Creating user...';
        statusDiv.className = '';

        const response = await fetch(`${API_BASE}/auth/admin/create-user`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username,
                email,
                full_name: fullName,
                password
            })
        });

        if (response.ok) {
            const data = await response.json();
            statusDiv.textContent = `User "${username}" created successfully!`;
            statusDiv.className = 'status-success';
            document.getElementById('admin-create-user-form').reset();

            // Refresh user list
            loadUsers();

            setTimeout(() => {
                statusDiv.textContent = '';
            }, 3000);
        } else {
            const error = await response.json();
            statusDiv.textContent = error.detail || 'Failed to create user';
            statusDiv.className = 'status-error';
        }
    } catch (error) {
        statusDiv.textContent = 'Error creating user';
        statusDiv.className = 'status-error';
    }
}

// Load users
async function loadUsers() {
    if (!isAdmin) return;

    try {
        const response = await fetch(`${API_BASE}/auth/users`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const users = await response.json();
            renderUsers(users);
        }
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

// Render users list
function renderUsers(users) {
    const list = document.getElementById('users-list');
    list.innerHTML = '';

    if (users.length === 0) {
        list.innerHTML = '<p style="text-align: center; color: #7f8c8d;">No users found</p>';
        return;
    }

    users.forEach(user => {
        const userDiv = document.createElement('div');
        userDiv.className = 'user-item';

        const isCurrentUser = currentUser && currentUser.id === user.id;

        userDiv.innerHTML = `
            <div class="user-info">
                <div class="user-name">${user.full_name || user.username}</div>
                <div class="user-email">${user.email}</div>
                <div class="user-username">@${user.username}</div>
            </div>
            <div class="user-actions">
                <div class="user-badges">
                    ${user.is_superuser ? '<span class="badge badge-admin">Admin</span>' : ''}
                    ${user.is_active ? '<span class="badge badge-active">Active</span>' : '<span class="badge badge-inactive">Inactive</span>'}
                </div>
                ${!isCurrentUser ? `<button class="btn-delete" data-user-id="${user.id}" data-username="${user.username}" title="Delete user">Delete</button>` : ''}
            </div>
        `;

        // Add delete button event listener
        if (!isCurrentUser) {
            const deleteBtn = userDiv.querySelector('.btn-delete');
            deleteBtn.addEventListener('click', () => confirmDeleteUser(user.id, user.username));
        }

        list.appendChild(userDiv);
    });
}

// Confirm delete user
async function confirmDeleteUser(userId, username) {
    const confirmed = await showConfirm(
        `Are you sure you want to delete user "${username}"? This action cannot be undone.`,
        'Delete User'
    );
    if (confirmed) {
        deleteUser(userId);
    }
}

// Delete user
async function deleteUser(userId) {
    if (!isAdmin) return;

    try {
        const response = await fetch(`${API_BASE}/auth/users/${userId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            showToast(data.message || 'User deleted successfully!', 'success');
            // Refresh user list
            loadUsers();
        } else {
            const error = await response.json();
            showToast(error.detail || 'Failed to delete user', 'error');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showToast('Error deleting user', 'error');
    }
}

// Confirm delete document
async function confirmDeleteDocument(docId, docTitle) {
    const confirmed = await showConfirm(
        `Are you sure you want to delete "${docTitle}"? This will remove the document and all its embeddings. This action cannot be undone.`,
        'Delete Document'
    );
    if (confirmed) {
        deleteDocument(docId);
    }
}

// Delete document
async function deleteDocument(docId) {
    try {
        const response = await fetch(`${API_BASE}/documents/${docId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            showToast(data.message || 'Document deleted successfully!', 'success');

            // Remove from selected documents if it was selected
            selectedDocuments = selectedDocuments.filter(d => d.id !== docId);

            // Clear session if needed
            if (currentSession) {
                currentSession = null;
                document.getElementById('chat-title').textContent = 'Select document(s) to start chatting';
                document.getElementById('chat-input').disabled = true;
                document.getElementById('send-btn').disabled = true;
                document.getElementById('chat-messages').innerHTML = '';
            }

            // Refresh document list
            loadDocuments();
            loadSessions();
        } else {
            const error = await response.json();
            showToast(error.detail || 'Failed to delete document', 'error');
        }
    } catch (error) {
        console.error('Error deleting document:', error);
        showToast('Error deleting document', 'error');
    }
}

// Confirm delete session
async function confirmDeleteSession(sessionId, sessionTitle) {
    const confirmed = await showConfirm(
        `Are you sure you want to delete chat session "${sessionTitle}"? This action cannot be undone.`,
        'Delete Session'
    );
    if (confirmed) {
        deleteSession(sessionId);
    }
}

// Delete session
async function deleteSession(sessionId) {
    try {
        const response = await fetch(`${API_BASE}/chat/sessions/${sessionId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (response.ok) {
            const data = await response.json();
            showToast(data.message || 'Session deleted successfully!', 'success');

            // Clear current session if it was deleted
            if (currentSession && currentSession.id === sessionId) {
                currentSession = null;
                document.getElementById('chat-messages').innerHTML = '';
                document.getElementById('chat-input').disabled = true;
                document.getElementById('send-btn').disabled = true;
            }

            // Refresh sessions list
            loadSessions();
        } else {
            const error = await response.json();
            showToast(error.detail || 'Failed to delete session', 'error');
        }
    } catch (error) {
        console.error('Error deleting session:', error);
        showToast('Error deleting session', 'error');
    }
}

// Poll for document status updates
setInterval(() => {
    if (authToken && documents.length > 0) {
        const pendingDocs = documents.filter(d => d.status === 'pending' || d.status === 'indexing');
        if (pendingDocs.length > 0) {
            loadDocuments();
        }
    }
}, 5000);
