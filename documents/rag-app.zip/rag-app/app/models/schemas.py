"""
Pydantic schemas for request/response validation
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime


# ============================================
# User Schemas
# ============================================

class UserBase(BaseModel):
    username: str = Field(..., min_length=2, max_length=50)
    email: EmailStr
    full_name: Optional[str] = None


class UserCreate(UserBase):
    password: str = Field(..., min_length=6)


class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    password: Optional[str] = None


class UserInDB(UserBase):
    id: int
    is_active: bool
    is_superuser: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class User(UserInDB):
    pass


# ============================================
# Auth Schemas
# ============================================

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    username: Optional[str] = None


class LoginRequest(BaseModel):
    username: str
    password: str


# ============================================
# Document Schemas
# ============================================

class DocumentBase(BaseModel):
    title: str = Field(..., min_length=1, max_length=255)


class DocumentCreate(DocumentBase):
    pass


class DocumentUpdate(BaseModel):
    title: Optional[str] = None


class DocumentInDB(DocumentBase):
    id: int
    filename: str
    file_path: str
    file_type: Optional[str]
    file_size: Optional[int]
    leann_index_id: Optional[str]
    status: str
    error_message: Optional[str]
    owner_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class Document(DocumentInDB):
    pass


# ============================================
# Chat Schemas
# ============================================

class ChatMessageBase(BaseModel):
    role: str = Field(..., pattern="^(user|assistant|system)$")
    content: str = Field(..., min_length=1)


class ChatMessageCreate(ChatMessageBase):
    pass


class ChatMessageInDB(ChatMessageBase):
    id: int
    session_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class ChatMessage(ChatMessageInDB):
    pass


class ChatSessionBase(BaseModel):
    title: Optional[str] = "New Chat"


class ChatSessionCreate(ChatSessionBase):
    document_id: Optional[int] = None  # For single document (backward compatibility)
    document_ids: Optional[List[int]] = None  # For multiple documents


class ChatSessionInDB(ChatSessionBase):
    id: int
    user_id: int
    document_id: int  # Primary document (always set)
    document_ids: Optional[str] = None  # JSON string of all documents
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ChatSession(ChatSessionInDB):
    messages: List[ChatMessage] = []


# ============================================
# RAG Schemas
# ============================================

class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=10000)  # Increased for complex prompts
    session_id: int
    top_k: int = Field(default=5, ge=1, le=20)


class QueryResponse(BaseModel):
    answer: str
    context_chunks: List[str]
    session_id: int
    message_id: int
    query_timestamp: datetime
    response_timestamp: datetime
    elapsed_time: float  # in seconds


class DocumentUploadResponse(BaseModel):
    document_id: int
    filename: str
    status: str
    message: str
