# RAG App Deployment Guide

## Architecture

```
Internet
   ↓
api.alztech.es (HTTPS)
   ↓
Pi Server (192.168.1.46 / 10.8.0.1)
   - Nginx Proxy
   ↓ WireGuard
Backend Server (10.8.0.2) ← YOU ARE HERE
   - Supervisor
   - RAG App (port 8002)
   - Ollama
```

## Deployment Steps

### Part 1: Backend Server Setup (10.8.0.2)

This is done on **THIS server** where you are now.

#### 1. Ensure Ollama is Running

```bash
# Check if Ollama is running
ollama list

# If not, start it
ollama serve &

# Pull required model
ollama pull qwen2.5:7b-instruct
```

#### 2. Create Directories

```bash
cd /home/erpnext/.www/projects/app/rag-app

# Create data directories
mkdir -p data/leann_index
mkdir -p uploads

# Create log directory
sudo mkdir -p /var/log/supervisor
```

#### 3. Generate Secret Key

```bash
# Generate a secure secret key
python -c "import secrets; print(secrets.token_urlsafe(32))"

# Update .env file with the generated key
nano .env
# Change SECRET_KEY=change-this-to-a-secure-random-key-in-production
# to the generated value
```

#### 4. Initialize Database

```bash
# Activate virtual environment
source /home/erpnext/fp15-env/bin/activate

# Initialize database
cd /home/erpnext/.www/projects/app/rag-app
python -c "from app.models import init_db; init_db()"
```

#### 5. Install Supervisor Configuration

```bash
# Copy supervisor config
sudo cp /home/erpnext/.www/projects/app/rag-app/rag-app.conf /etc/supervisor/conf.d/

# Update supervisor
sudo supervisorctl reread
sudo supervisorctl update

# Start the app
sudo supervisorctl start rag-app

# Check status
sudo supervisorctl status rag-app
```

Expected output:
```
rag-app                          RUNNING   pid 12345, uptime 0:00:05
```

#### 6. Test Local Access

```bash
# Test health endpoint
curl http://localhost:8002/health

# Should return: {"status":"healthy","app":"RAG Document Chat","version":"1.0.0"}
```

### Part 2: Pi Server Nginx Configuration (10.8.0.1)

This must be done on the **Pi server** by someone with access (ddm1n4Pibi).

#### Instructions for Pi Server Admin:

1. SSH to pi server:
   ```bash
   ssh pi@192.168.1.46
   # or via WireGuard:
   ssh pi@10.8.0.1
   ```

2. Edit nginx config:
   ```bash
   sudo nano /etc/nginx/conf.d/api.alztech.es.conf
   ```

3. Add these location blocks to the existing server block:

   ```nginx
   location /rag-app/ {
       proxy_pass http://10.8.0.2:8002/;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection 'upgrade';
       proxy_set_header Host $host;
       proxy_cache_bypass $http_upgrade;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_read_timeout 300s;
       proxy_connect_timeout 300s;
       proxy_send_timeout 300s;
       client_max_body_size 100M;
   }

   location /rag-app/api/ {
       proxy_pass http://10.8.0.2:8002/api/;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection 'upgrade';
       proxy_set_header Host $host;
       proxy_cache_bypass $http_upgrade;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_read_timeout 300s;
       proxy_connect_timeout 300s;
       proxy_send_timeout 300s;
       client_max_body_size 100M;
   }

   location /rag-app/static/ {
       proxy_pass http://10.8.0.2:8002/static/;
       proxy_http_version 1.1;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
   }
   ```

   **Note**: The complete config snippet is in `/home/erpnext/.www/projects/app/rag-app/nginx-rag-app.conf`

4. Test and reload nginx:
   ```bash
   sudo nginx -t
   sudo systemctl reload nginx
   ```

### Part 3: Verification

#### From Backend Server (10.8.0.2):

```bash
# Check app is running
sudo supervisorctl status rag-app

# Check logs
tail -f /var/log/supervisor/rag-app.log

# Test local access
curl http://localhost:8002/health
```

#### From Pi Server (10.8.0.1):

```bash
# Test backend via WireGuard
curl http://10.8.0.2:8002/health

# Test through nginx
curl http://localhost/rag-app/health
```

#### From Internet:

```bash
# Test external access
curl https://api.alztech.es/rag-app/health
```

#### Web Browser:

Open: https://api.alztech.es/rag-app/

## URLs

Once deployed:

- **Main Interface**: https://api.alztech.es/rag-app/
- **API Docs**: https://api.alztech.es/rag-app/api/docs
- **Health Check**: https://api.alztech.es/rag-app/health

Internal URLs (backend server):
- http://localhost:8002/
- http://10.8.0.2:8002/ (via WireGuard)

## Supervisor Commands (Backend Server)

```bash
# Start
sudo supervisorctl start rag-app

# Stop
sudo supervisorctl stop rag-app

# Restart
sudo supervisorctl restart rag-app

# Status
sudo supervisorctl status rag-app

# View logs
tail -f /var/log/supervisor/rag-app.log
tail -f /var/log/supervisor/rag-app.error.log
```

## Port Configuration

- **8001**: docling app
- **8002**: rag-app (this application)

## Network Setup

- **Backend Server**: 10.8.0.2 (WireGuard) - Runs supervisor + app
- **Pi Server**: 10.8.0.1 (WireGuard), 192.168.1.46 (LAN) - Runs nginx proxy
- **WireGuard Network**: 10.8.0.0/24

## Troubleshooting

### App won't start

```bash
# Check logs
tail -n 50 /var/log/supervisor/rag-app.error.log

# Common issues:

# 1. Port already in use
sudo netstat -tlnp | grep 8002

# 2. Missing dependencies
source /home/erpnext/fp15-env/bin/activate
pip install -r requirements.txt

# 3. Database not initialized
cd /home/erpnext/.www/projects/app/rag-app
python -c "from app.models import init_db; init_db()"

# 4. Ollama not running
ollama serve &
```

### Ollama connection errors

```bash
# Check Ollama status
ollama list

# Test Ollama
curl http://localhost:11434/api/tags

# Check if model is available
ollama list | grep qwen2.5

# Restart Ollama if needed
pkill ollama
ollama serve &
```

### Permission issues

```bash
# Fix ownership
sudo chown -R erpnext:erpnext /home/erpnext/.www/projects/app/rag-app
sudo chown -R erpnext:erpnext /home/erpnext/.www/projects/app/rag-app/data
sudo chown -R erpnext:erpnext /home/erpnext/.www/projects/app/rag-app/uploads
```

### Can't access via api.alztech.es

```bash
# Check WireGuard connection (backend server)
sudo wg show

# Should see peer 10.8.0.1 with recent handshake

# Test connectivity to pi
ping 10.8.0.1

# Test if app is accessible via WireGuard
curl http://10.8.0.2:8002/health
```

On pi server (ask ddm1n4Pibi):
```bash
# Check nginx status
sudo systemctl status nginx

# Check nginx logs
sudo tail -f /var/log/nginx/error.log

# Test proxy to backend
curl http://10.8.0.2:8002/health
```

## Monitoring

```bash
# Watch logs in real-time
tail -f /var/log/supervisor/rag-app.log

# Check resource usage
top -p $(pgrep -f "main_runner")

# Check Ollama GPU/memory usage
nvidia-smi  # If using GPU

# Check WireGuard connection
sudo wg show
```

## Backup

Important files to backup:

```bash
# Backup command
tar -czf rag-app-backup-$(date +%Y%m%d).tar.gz \
  /home/erpnext/.www/projects/app/rag-app/data/ \
  /home/erpnext/.www/projects/app/rag-app/uploads/ \
  /home/erpnext/.www/projects/app/rag-app/rag_app.db \
  /home/erpnext/.www/projects/app/rag-app/.env
```

## Security

1. **SECRET_KEY**: Generate and update in `.env`
2. **Database**: Stored locally, backed up regularly
3. **Uploads**: Stored locally in `uploads/` directory
4. **HTTPS**: Handled by nginx on pi server
5. **WireGuard**: Encrypted tunnel between servers

## Contact

- **System Admin**: ddm1n4Pibi
- **Pi Server**: 192.168.1.46 (LAN) / 10.8.0.1 (WireGuard)
- **Backend Server**: 10.8.0.2 (WireGuard)
- **Domain**: api.alztech.es

## Quick Reference

```bash
# On Backend Server (where you are now):

# Start app
sudo supervisorctl start rag-app

# View logs
tail -f /var/log/supervisor/rag-app.log

# Test locally
curl http://localhost:8002/health

# Check WireGuard
sudo wg show
```
