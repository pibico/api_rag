#!/usr/bin/env python3
"""
Create an admin user for RAG app
Usage: python create_admin.py
"""
import sys
sys.path.insert(0, '/home/erpnext/.www/projects/app/rag-app')

from app.models.database import SessionLocal, User
from app.services.auth import get_password_hash

def create_admin_user(username: str, email: str, password: str, full_name: str = ""):
    """Create an admin user"""
    db = SessionLocal()

    try:
        # Check if user already exists
        existing_user = db.query(User).filter(User.username == username).first()
        if existing_user:
            print(f"❌ User '{username}' already exists!")
            return False

        # Create admin user
        hashed_password = get_password_hash(password)
        admin_user = User(
            username=username,
            email=email,
            full_name=full_name,
            hashed_password=hashed_password,
            is_superuser=True,  # This makes the user an admin
            is_active=True
        )

        db.add(admin_user)
        db.commit()
        db.refresh(admin_user)

        print(f"✓ Admin user created successfully!")
        print(f"  Username: {username}")
        print(f"  Email: {email}")
        print(f"  Admin: Yes")
        print(f"\nYou can now login at: https://api.alztech.es/rag-app/")

        return True

    except Exception as e:
        print(f"❌ Error creating admin user: {e}")
        db.rollback()
        return False
    finally:
        db.close()


if __name__ == "__main__":
    print("╔══════════════════════════════════════════════════════════╗")
    print("║        RAG App - Admin User Creation                    ║")
    print("╚══════════════════════════════════════════════════════════╝\n")

    username = input("Admin username: ").strip()
    email = input("Admin email: ").strip()
    full_name = input("Full name (optional): ").strip()
    password = input("Password: ").strip()
    confirm_password = input("Confirm password: ").strip()

    if not username or not email or not password:
        print("❌ Username, email, and password are required!")
        sys.exit(1)

    if password != confirm_password:
        print("❌ Passwords do not match!")
        sys.exit(1)

    if len(password) < 6:
        print("❌ Password must be at least 6 characters!")
        sys.exit(1)

    print("\n" + "="*60)
    create_admin_user(username, email, password, full_name)
