# How to Update Nginx on Pi Server

## Current Situation

The nginx config on pi (192.168.1.46 / 10.8.0.1) currently only has:
- `/docling/` → proxies to 10.8.0.2:8001

We need to add:
- `/rag-app/` → proxies to 10.8.0.2:8002

## Steps for ddm1n4Pibi or Pi Admin

### Option 1: SSH and Edit Manually

1. SSH to pi:
   ```bash
   ssh pi@192.168.1.46
   # Password: @gd,1m1n4Pibi
   ```

2. Edit nginx config:
   ```bash
   sudo nano /etc/nginx/conf.d/api.alztech.es.conf
   ```

3. Add these location blocks (after the `/docling/` block):

   ```nginx
   location /rag-app/ {
       proxy_pass http://10.8.0.2:8002/;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection 'upgrade';
       proxy_set_header Host $host;
       proxy_cache_bypass $http_upgrade;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_read_timeout 300s;
       proxy_connect_timeout 300s;
       proxy_send_timeout 300s;
       client_max_body_size 100M;
   }

   location /rag-app/api/ {
       proxy_pass http://10.8.0.2:8002/api/;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection 'upgrade';
       proxy_set_header Host $host;
       proxy_cache_bypass $http_upgrade;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_read_timeout 300s;
       proxy_connect_timeout 300s;
       proxy_send_timeout 300s;
       client_max_body_size 100M;
   }

   location /rag-app/static/ {
       proxy_pass http://10.8.0.2:8002/static/;
       proxy_http_version 1.1;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
   }
   ```

4. Save and exit (Ctrl+X, Y, Enter)

5. Test and reload nginx:
   ```bash
   sudo nginx -t
   sudo systemctl reload nginx
   ```

6. Verify:
   ```bash
   # Test from pi
   curl http://10.8.0.2:8002/health
   curl http://localhost/rag-app/health

   # Test from internet
   curl https://api.alztech.es/rag-app/health
   ```

### Option 2: Copy Config File

The complete config is available at:
- `/home/erpnext/.www/projects/app/rag-app/nginx-complete-config.txt`

This file shows both docling and rag-app configurations.

### Expected Result

After updating, the nginx config on pi should have:

```nginx
server {
    # ... server config ...

    # Docling app (existing)
    location /docling/ {
        proxy_pass http://10.8.0.2:8001/;
        # ... headers ...
    }

    # RAG app (new)
    location /rag-app/ {
        proxy_pass http://10.8.0.2:8002/;
        # ... headers ...
    }

    location /rag-app/api/ {
        proxy_pass http://10.8.0.2:8002/api/;
        # ... headers ...
    }

    location /rag-app/static/ {
        proxy_pass http://10.8.0.2:8002/static/;
        # ... headers ...
    }
}
```

## Verification

After nginx is updated on pi, test from this backend server:

```bash
# Should return health status
curl https://api.alztech.es/rag-app/health

# Should return API docs HTML
curl https://api.alztech.es/rag-app/api/docs

# Should return the web interface
curl https://api.alztech.es/rag-app/
```

## Network Flow

```
User → api.alztech.es:443 (HTTPS)
  ↓
Pi (10.8.0.1) - Nginx
  ↓ /rag-app/ → proxy_pass http://10.8.0.2:8002/
Backend (10.8.0.2) - FastAPI on port 8002
```

## Contact

If you need help updating the nginx config:
- Contact: ddm1n4Pibi
- Pi Server: 192.168.1.46 or 10.8.0.1
- Config file: /etc/nginx/conf.d/api.alztech.es.conf
